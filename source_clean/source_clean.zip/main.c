#include "ui.h"

int main() {
  runUI();
  return 0;
}
