#ifndef UTILS_H
#define UTILS_H

void clearScreen();

#endif // UTILS_H
